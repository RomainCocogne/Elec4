/**
*   Description: Draw a fractal window
*                you can switch between mandelbrot and julia fractal
*   Author: Romain Cocogne
*   Version: 1.0
*/
#pragma once

#include <QtWidgets>
#include <vector>
#include <iostream>
#include <complex>
#include <cmath>
#include <thread>
#include "./Functor.h"
#include "./util.h"

QT_BEGIN_NAMESPACE
class QImage;
QT_END_NAMESPACE

using std::get;
using std::vector;


class FractalImage: public QImage {
 protected:
    const int nmax_ = 512;  // for maximum iteration of loop
    const int ncolor_ = 65536;  // threshold for coloring pixel
    const Gradient grad = Gradient(2048);   // color gradient for coloring pixel

    double xc_;
    double  yc_;
    double d_;

    int w_;
    int h_;

    // draw (x,y) pixel using complex formula zn = zn*zn + c
    // xn0, yn0 are initial values of zn
    // x0, y0 are values of c
    void compute_pixel_complex(const double &xn0, const double &yn0,
                       const double &x0, const double &y0,
                       const int &x, const int &y) {

        std::complex<double> zn(xn0, yn0);  // first element
        std::complex<double> c(x0, y0);
        bool inside_fract = true;
        int n;
        for (n = 0; n <nmax_; ++n) {
            zn = zn*zn + c; // next element
            if (!(std::norm(zn) < ncolor_)) {   // test convergence
                inside_fract = false;
                break;
            }
        }
        if (inside_fract) {
            setPixel(x, y, qRgb(0, 0, 0));
        } else {    // compute the pixel color
            double v = log2(log2((std::norm(zn))));
            int i = (1024*sqrt(n+5-v));
            setPixel(x, y, grad[i%2048]);
        }
    }

    // draw (x,y) pixel using same formula as compute_pixel_complex
    // but without complex objects
    void compute_pixel(const double &xn0, const double &yn0,
                       const double &x0, const double &y0,
                       const int &x, const int &y) {
        double xn = xn0;
        double yn = yn0;
        double xn_square = xn*xn;
        double yn_square = yn*yn;
        auto abs_zn = xn_square+yn_square;
        bool inside_fract = true;
        int n;
        for (n = 0; n <nmax_; ++n) {
            yn = 2*xn*yn +y0;
            xn = xn_square - yn_square + x0;
            xn_square = xn * xn;
            yn_square = yn * yn;

            abs_zn = xn_square+yn_square;
            if (!(abs_zn < ncolor_)) {
                inside_fract = false;
                break;
            }
        }
        if (inside_fract) {
            setPixel(x, y, qRgb(0, 0, 0));
        } else {
            double v = log2(log2((abs_zn)));
            int i = (1024*sqrt(n+5-v));
            setPixel(x, y, grad[i%2048]);
        }
    }

    // draw one portion of fractal image
    void process_sub_image(int i, int m) {
        Map<double> y_displ_to_plan(0,  h_, yc_+d_, yc_-d_);
        Map<double> x_displ_to_plan(0,  w_, xc_-1.5*d_, xc_+1.5*d_);

        const int ypos_start = i*(h_)/m;
        const int ypos_stop  = (i+1)*(h_)/m;

        for (int y = ypos_start; y < ypos_stop; ++y) {
            auto y0 = y_displ_to_plan(y);
            for (int x = 0; x < w_; ++x) {
                auto x0 = x_displ_to_plan(x);
                make_fractal_pixel(x0, y0, x, y);
            }
        }
    }

    // virtual method to be used as wrapper of
    // compute_pixel in child classes
    virtual void make_fractal_pixel(const double &x0, const double &y0,
                                    const int &x, const int &y) = 0;

 public:
    FractalImage(double xc, double yc, double d, int width, int height):
        QImage(width, height, QImage::Format_RGB32),
        xc_{xc}, yc_{yc}, d_{d},
        w_{width}, h_{height} {}

    // multi-threaded method
    // drawing fractal image
    void make_fractal() {
        std::vector<std::thread> threads;
        int max_threads = 4;
        for (int i = 0; i < max_threads; i++) {
            threads.emplace_back([=]() {
                process_sub_image(i, max_threads);
            });
        }
        for (auto &thread_elem : threads)
            thread_elem.join();
    }
//    void resize(const int &w, const int &h){
//        w_ = w;
//        h_ = h;
//    }
//    int height() {return h_;}
//    int width() {return w_;}
};

/*
 * 2 types of fractals
 * using the same formula but not same initial conditions
 */

class MandelbrotImage: public FractalImage {
 public:
    MandelbrotImage(double xc, double yc, double d, int width, int height):
        FractalImage(xc, yc, d, width, height) {}
 protected:
    void make_fractal_pixel(const double &x0, const double &y0,
                            const int &x, const int &y) override {
        compute_pixel(0, 0, x0, y0, x, y);
    }
};

class JuliaImage: public FractalImage{
 public:
    JuliaImage(double xc, double yc, double d, int width, int height):
        FractalImage(xc, yc, d, width, height) {}
 protected:
    void make_fractal_pixel(const double &x0, const double &y0,
                            const int &x, const int &y) override {
        compute_pixel(x0, y0, -0.4, 0.6, x, y);
    }
};
