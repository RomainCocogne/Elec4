// Copyright none
#include <QtWidgets>
#include <iostream>
#include <chrono>
#include <string>
#include <algorithm>
#include <memory>
#include "./mainwindow.h"
#include "./Functor.h"
#include "./util.h"
#include "./triangleImage.h"
#include "./splineimage.h"
#include "./fractal.h"


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
  //
  // construct image_widget

  image_widget_ = new QLabel;
  image_widget_->setBackgroundRole(QPalette::Base);
  image_widget_->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
  image_widget_->setScaledContents(true);
  image_widget_->setMinimumSize(600, 600);

  create_actions();
  create_menus();

  setCentralWidget(image_widget_);
  resize(QGuiApplication::primaryScreen()->availableSize() * 2 / 5);

  //
  current_window_fractal_ = false;
}


void MainWindow::create_actions() {
  //
  action_triangle_image_ = new QAction(tr("Triangle Image"), this);
  connect(action_triangle_image_, SIGNAL(triggered()),
          this, SLOT(slot_triangle_image()));
  action_spline_image_ = new QAction(tr("Spline Image"), this);
  connect(action_spline_image_, SIGNAL(triggered()),
          this, SLOT(slot_spline_image()));
  action_mandelbrot_image_ = new QAction(tr("Mandelbrot Fractal Image"), this);
  connect(action_mandelbrot_image_, SIGNAL(triggered()),
          this, SLOT(slot_mandelbrot_image()));

  action_exit_ = new QAction(tr("E&xit"), this);
  action_exit_->setShortcut(tr("Ctrl+Q"));
  connect(action_exit_, SIGNAL(triggered()), this, SLOT(slot_exit()));

  action_about_ = new QAction(tr("&About"), this);
  connect(action_about_, SIGNAL(triggered()), this, SLOT(slot_about()));
}

void MainWindow::slot_exit() {
  close();
}

void MainWindow::slot_about() {
    QMessageBox::about(this, tr("About Image Viewer"),
    tr("<p>The user can select several images to be displayed on the screen</p>"));
}


void MainWindow::create_menus() {
  menu_open_ = new QMenu(tr("&Open"), this);

  menu_open_->addAction(action_triangle_image_);
  menu_open_->addAction(action_spline_image_);
  menu_open_->addAction(action_mandelbrot_image_);
  menu_open_->addAction(action_exit_);


  menu_help_ = new QMenu(tr("&Help"), this);
  menu_help_->addAction(action_about_);

  menuBar()->addMenu(menu_open_);
  menuBar()->addMenu(menu_help_);
}



// triangle subwindow
const int triangle_width = 600;
const int triangle_height = 600;

void MainWindow::slot_triangle_image() {
  //
  current_window_fractal_ = false;
  //
  TriangleImage triangle_image(triangle_width, triangle_height);
  image_widget_->setPixmap(QPixmap::fromImage(triangle_image));
  image_widget_->setFixedSize(triangle_width, triangle_height);
  adjustSize();
}

// Spline image subwindow
const int spline_width = 1024;
const int spline_height = 512;

void MainWindow::slot_spline_image() {
  //
  current_window_fractal_ = false;
  //
  SplineImage spline_image(spline_width, spline_height);
  image_widget_->setPixmap(QPixmap::fromImage(spline_image));
  image_widget_->setFixedSize(spline_width, spline_height);
  adjustSize();
}

// fractal subwindow
const int fractal_width = 600;
const int fractal_height = 400;
void MainWindow::slot_mandelbrot_image() {
  //
  current_window_fractal_ = true;
  //
  // measuring construct time
  auto start = std::chrono::high_resolution_clock::now();
  // first fractal is mandelbrot with fixed xd, yd, d parameters
  std::unique_ptr<FractalImage> first_fract =
          std::make_unique<MandelbrotImage>(-0.5, 0, 1, fractal_width, fractal_height);
  first_fract->make_fractal();
  auto end = std::chrono::high_resolution_clock::now();
  auto elapsed_time = end - start;
  std::cout << "Info: image calculated in "
            << Commify(elapsed_time.count()) << " ns, or "
            << elapsed_time.count()/1000000000.0 << " s" << std::endl;

  image_widget_->setPixmap(QPixmap::fromImage(*first_fract.get()));
  image_widget_->setFixedSize(fractal_width, fractal_height);
  adjustSize();
}

// event for fractal navigation
void MainWindow::keyPressEvent(QKeyEvent *event) {
  if (current_window_fractal_) {
      static bool fract_julia = false;  // choose wich fractal to display
      static std::unique_ptr<FractalImage> current_fract;
      static double xc = -0.5;  // initial values
      static double yc = 0;
      static double d = 1;
      bool pressed = false;

      switch (event->key()) {
      case Qt::Key_T:   // toggle
          fract_julia = !fract_julia;
          pressed = true;
          break;
      case Qt::Key_Left:    // go left
              xc -= 0.1*d;
              pressed = true;
          break;
      case Qt::Key_Right:   // go right
              xc += 0.1*d;
              pressed = true;
          break;
      case Qt::Key_Up:  // go up
              yc += 0.1*d;
              pressed = true;
          break;
      case Qt::Key_Down:    // go down
              yc -= 0.1*d;
              pressed = true;
          break;
      case Qt::Key_Plus:    // zoom in
              d = d/10;
              pressed = true;
          break;
      case Qt::Key_Minus:   // zoom out
              d = d*1.5;
              pressed = true;
          break;

      default:
          QMainWindow::keyPressEvent(event);
        }

        if (pressed) {  // if change detected, we update the screen
          if (fract_julia)
            current_fract = std::make_unique<JuliaImage>
                    (xc, yc, d, fractal_width, fractal_height);
          else
            current_fract = std::make_unique<MandelbrotImage>
                    (xc, yc, d, fractal_width, fractal_height);

          auto start = std::chrono::high_resolution_clock::now();
          current_fract->make_fractal();
          auto end = std::chrono::high_resolution_clock::now();
          auto elapsed_time = end - start;
          std::cout << "Info: image calculated in "
                    << Commify(elapsed_time.count()) << " ns, or "
                    << elapsed_time.count()/1000000000.0 << " s" << std::endl;

          image_widget_->setPixmap(QPixmap::fromImage(*current_fract.get()));
          image_widget_->setFixedSize(fractal_width, fractal_height);
          adjustSize();
        }
  }

}


