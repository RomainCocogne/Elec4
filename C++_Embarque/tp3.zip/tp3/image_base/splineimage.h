/**
*   Description: class drawing a color gradient and the
*                corresponding RBG concentration
*   Author: Romain Cocogne
*   Version: 1.0
*/
#pragma once

#include <QtWidgets>
#include <vector>
#include <iostream>
#include "./Functor.h"
#include "./util.h"

QT_BEGIN_NAMESPACE
class QImage;
QT_END_NAMESPACE

using std::vector;

class SplineImage: public QImage {
 private:
    // values of RGB gradient for normalised x
    const vector<double> xs_ { 0., 0.16, 0.42, 0.6425, 0.8575 };
    const vector<double> yr_ { 0., 32. , 237. , 215., 0. };
    const vector<double> yg_ { 7., 107. , 255. , 170., 10. };
    const vector<double> yb_ { 100., 183. , 235. , 40., 15. };


    // plot the xy axis with the following zoom factor
    // -0.05 < x < 1.05
    // -10 < y < 265
    void draw_grid(QPainter *painter,
                   const double &width,
                   const double &height) {
        painter->setPen(Qt::white);
        Map<double> y_normalized(-10, 265, 0, 1);
        Map<double> x_normalized(-0.05, 1.05, 0, 1);

        // draw lines for each values in x_ plus x=1
        for (auto xs : xs_)
            painter->drawLine(x_normalized(xs)*width, 0,
                             x_normalized(xs)*width, height);
        painter->drawLine(x_normalized(1)*width, 0,
                         x_normalized(1)*width, height);
        // draw max and min values for y
        QPen pen(Qt::white);
        pen.setDashPattern({5, 5});
        pen.setStyle(Qt::CustomDashLine);
        painter->setPen(pen);
        painter->drawLine(0, y_normalized(0)*height,
                         width, y_normalized(0)*height);
        painter->drawLine(0, y_normalized(255)*height,
                         width, y_normalized(255)*height);
    }

    // draw the grandient using the linear interpolation
    // plus the corresponding RGB concentration
    void draw_waves(QPainter *painter,
                     const double &width,
                     const double &height) {
        Clamp<int> clamp_to_height(0, height-1);
        Clamp<int> clamp_to_rgb(0, 255);
        Map<double> x_normalized(0, width, -0.05, 1.05);
        Map<double> color_to_plan(-10, 265, height, 0);

        // linear interpolation
        Linear splineGreen(xs_, yg_);
        Linear splineBlue(xs_, yb_);
        Linear splineRed(xs_, yr_);

        for (double x = 0; x < width; ++x) {
            double x_n = x_normalized(x);

            // RGB value
            int r = clamp_to_rgb(splineRed(x_n));
            int g = clamp_to_rgb(splineGreen(x_n));
            int b = clamp_to_rgb(splineBlue(x_n));

            // individual concentration
            int yg = clamp_to_height(color_to_plan(g));
            int yb = clamp_to_height(color_to_plan(b));
            int yr = clamp_to_height(color_to_plan(r));

            painter->setPen(qRgb(r, g, b));
            painter->drawLine(x, 0, x, height);

            setPixel(x, yg, qRgb(0, 255, 0));
            setPixel(x, yb, qRgb(0, 0, 255));
            setPixel(x, yr, qRgb(255, 0, 0));
        }
    }

 public:
    // Constructor, drawing all the image at once
    SplineImage(int width, int height):
        QImage(width, height, QImage::Format_RGB32) {
        QPainter painter(this);
        painter.fillRect(rect(), Qt::black);

        draw_waves(&painter, width, height);
        draw_grid(&painter, width, height);
    }
};
