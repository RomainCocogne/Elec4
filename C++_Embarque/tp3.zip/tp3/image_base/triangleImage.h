/**
*   Description: class drawing a colored triangle into a window
*   Author: Romain Cocogne
*   Version: 1.0
*/
#pragma once

#include <QtWidgets>

QT_BEGIN_NAMESPACE
class QImage;
QT_END_NAMESPACE

class TriangleImage : public QImage {
 private:
    QPointF red_;
    QPointF green_;
    QPointF blue_;
    QPointF white_;

    // Compute the xy location inside the window into
    // a RGB color using barycentric coordinates
    QRgb xy_to_rgb(const QPointF &current) const {
        const double r = (((green_.y()-blue_.y())*(current.x()-blue_.x())
                            +(blue_.x()-green_.x())*(current.y()-blue_.y()))
                          /((green_.y()-blue_.y())*(red_.x()-blue_.x())
                            +(blue_.x()-green_.x())*(red_.y()-blue_.y())));
        const double v = (((blue_.y()-red_.y())*(current.x()-blue_.x())
                            +(red_.x()-blue_.x())*(current.y()-blue_.y()))
                          /((green_.y()-blue_.y())*(red_.x()-blue_.x())
                            +(blue_.x()-green_.x())*(red_.y()-blue_.y())));
        const double b = (1-r-v);
        return qRgb(r*255, v*255, b*255);
    }

    // Draw the background grid
    void draw_grid(QPainter *painter, const int &width, const int &height) {
        // greenish color
        QPen pen(qRgb(51, 204, 102));
        // the grid is dashed
        pen.setDashPattern({5, 5});
        pen.setStyle(Qt::CustomDashLine);
        painter->setPen(pen);
        // Draw 10 lines in width and 10 lines in height
        const int step_width = width/10;
        const int step_height = height/10;
        for (int y = step_height; y < height; y+=step_height)
            painter->drawLine(0, y, width, y);
        for (int x = step_width; x < width; x+=step_width)
            painter->drawLine(x, 0, x, height);
    }

 public:
    // Constructor
    // draw all elements of the window
    TriangleImage(const int &width, const int &height):
        QImage(width, height, QImage::Format_RGB32),
        red_(0.64*width, (1-0.33)*height),
        green_(0.3*width, (1-0.6)*height),
        blue_(0.15*width, (1-0.06)*height),
        white_(0.3127*width, (1-0.32903)*height) {
        QPainter painter(this);
        painter.fillRect(rect(), Qt::black);
        // draw the backgroud grid
        draw_grid(&painter, width, height);
        // draw and fill the triangle
        QPolygonF triangle({red_, green_, blue_});
        for (int y = 0; y < height; ++y)
          for (int x = 0; x < width; ++x)
            // is the point inside the triangle ?
            if (triangle.containsPoint(QPointF(x, y), Qt::OddEvenFill))
                setPixel(x, y, xy_to_rgb(QPointF(x, y)));
    }
};
