/**
*   Description: Some util classes
*   Author: Romain Cocogne
*   Version: 1.0
*/
#pragma once
#include <QColor>
#include <vector>
#include <algorithm>
#include <iostream>
#include <string>
#include "./Functor.h"

using std::string;
using std::vector;

// Commify unsigned lon int value
class Commify {
 private:
    uint32_t val_;
 public:
    explicit Commify(uint32_t value):val_{value} {}

    friend std::ostream &operator << (std::ostream &f, const Commify &c){
        ostringstream ss;
        ss << c.val_;
        string s = ss.str();
        int insertPosition = s.length() - 3;
        while (insertPosition > 0) {
            s.insert(insertPosition, ",");
            insertPosition -= 3;
        }
        f << s;
        return f;
    }
};

// make a RGB color gradient
// with the linear interpolation method
// and save it in a vector
class Gradient {
 private:
    const vector<double> xs_ { 0., 0.16, 0.42, 0.6425, 0.8575 };
    const vector<double> yr_ { 0., 32. , 237. , 215., 0. };
    const vector<double> yg_ { 7., 107. , 255. , 170., 10. };
    const vector<double> yb_ { 100., 183. , 235. , 40., 15. };

    // values of gradient
    vector<QRgb> color_tab_;

 public:
    // Constructor of the gradient
    // i is the size of the resulting vector
    Gradient(const int &i) {
        color_tab_.reserve(i);

        // using same gradient as in SlineImage class
        Map<double> x_normalized(0, i, -0.05, 1.05);
        Clamp<double> clamp_to_rgb(0, 255);

        Linear splineGreen(xs_, yg_);
        Linear splineBlue(xs_, yb_);
        Linear splineRed(xs_, yr_);

        for (auto x = 0; x < i; ++x){
            double x_n = x_normalized(x);
            int r=clamp_to_rgb(splineRed(x_n));
            int g=clamp_to_rgb(splineGreen(x_n));
            int b=clamp_to_rgb(splineBlue(x_n));
            color_tab_[x] = qRgb(r, g, b);
        }
    }

    // to be used as an array
    QRgb operator [] (const int &i) const{
        return color_tab_[i];
    }
};
